 - Points coordinates can be found and changed in /Storage/Coordinates.txt

 - Start FurthestPoint.exe to run the calculations.

 - Calculation result is stored in /Storage/output.txt

 - Calculation result can be met in the console popup window as well.